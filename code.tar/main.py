import sys
import itertools
from collections import defaultdict

def load_data(filename):
    baskets = []
    with open(filename, 'r') as f:
        for line in f:
            items = line.strip().split(',')
            baskets.append(set(item.strip() for item in items if item.strip() != ''))
    return baskets

def get_frequent_itemsets(baskets, min_sup):
    itemset_counts = defaultdict(int)
    total_baskets = len(baskets)
    for basket in baskets:
        for item in basket:
            itemset_counts[frozenset([item])] += 1

    frequent_itemsets = {}
    current_lset = {itemset for itemset, count in itemset_counts.items()
                    if count / total_baskets >= min_sup}

    k = 2
    while current_lset:
        for itemset in current_lset:
            frequent_itemsets[tuple(sorted(itemset))] = itemset_counts[itemset]

        candidate_itemsets = set(
            frozenset(i.union(j)) for i in current_lset for j in current_lset
            if len(i.union(j)) == k
        )

        itemset_counts = defaultdict(int)
        for basket in baskets:
            for candidate in candidate_itemsets:
                if candidate.issubset(basket):
                    itemset_counts[candidate] += 1

        current_lset = {itemset for itemset, count in itemset_counts.items()
                        if count / total_baskets >= min_sup}
        k += 1

    return frequent_itemsets, total_baskets

def generate_rules(frequent_itemsets, total_baskets, min_conf):
    rules = []
    for itemset in frequent_itemsets:
        itemset_set = set(itemset)
        if len(itemset) < 2:
            continue
        support = frequent_itemsets[itemset] / total_baskets
        for i in range(1, len(itemset)):
            for lhs in itertools.combinations(itemset, i):
                lhs = set(lhs)
                rhs = itemset_set - lhs
                if len(rhs) != 1:
                    continue
                lhs_tuple = tuple(sorted(lhs))
                if lhs_tuple in frequent_itemsets:
                    conf = frequent_itemsets[itemset] / frequent_itemsets[lhs_tuple]
                    if conf >= min_conf:
                        rules.append((sorted(lhs), sorted(rhs)[0], conf, support))
    return rules


def write_output(frequent_itemsets, rules, total_baskets, min_sup, min_conf):
    with open('output.txt', 'w') as f:
        f.write(f"== Frequent Itemsets (min_sup = {min_sup*100:.1f}%) ==\n")
        f.write(f"{'Items':<60} | Support (%)\n")
        f.write(f"{'-'*80}\n")
        for itemset, count in sorted(frequent_itemsets.items(), key=lambda x: -x[1]):
            supp = count / total_baskets * 100
            f.write(f"[{', '.join(itemset):<60}] | {supp:.2f}%\n")

        f.write(f"\n== High-Confidence Association Rules (min_conf = {min_conf*100:.1f}%) ==\n")
        f.write(f"{'Rule':<80} | Confidence (%) | Support (%)\n")
        f.write(f"{'-'*120}\n")
        for lhs, rhs, conf, supp in sorted(rules, key=lambda x: -x[2]):
            lhs_text = ", ".join(lhs)
            rule_text = f"[{lhs_text}] => [{rhs}]"
            f.write(f"{rule_text:<80} | {conf*100:.2f}% | {supp*100:.2f}%\n")



if __name__ == "__main__":
    if len(sys.argv) != 4:
        print("Usage: python3 main.py market_basket_dataset.csv min_sup min_conf")
        sys.exit(1)

    filename = sys.argv[1]
    min_sup = float(sys.argv[2])
    min_conf = float(sys.argv[3])

    baskets = load_data(filename)
    frequent_itemsets, total_baskets = get_frequent_itemsets(baskets, min_sup)
    rules = generate_rules(frequent_itemsets, total_baskets, min_conf)
    write_output(frequent_itemsets, rules, total_baskets, min_sup, min_conf)
