import pandas as pd

def transform_to_basket(input_csv='INTEGRATED_DATASET.csv', output_csv='market_basket_dataset.csv'):
    df = pd.read_csv(input_csv)

    columns_to_keep = [
        'BORO',
        'CUISINE DESCRIPTION',
        'VIOLATION CODE',
        'GRADE'
    ]

    df_filtered = df[columns_to_keep]

    df_filtered = df_filtered.dropna()

    baskets = []

    for idx, row in df_filtered.iterrows():
        basket = []
        for col in columns_to_keep:
            value = str(row[col]).strip()
            if value != '' and value.lower() != 'nan':
                basket.append(value)
        if basket:
            baskets.append(basket)

    with open(output_csv, 'w') as f:
        for basket in baskets:
            f.write(','.join(basket) + '\n')

    print(f" Basket-format dataset saved as '{output_csv}' with {len(baskets)} baskets.")

if __name__ == '__main__':
    transform_to_basket()
